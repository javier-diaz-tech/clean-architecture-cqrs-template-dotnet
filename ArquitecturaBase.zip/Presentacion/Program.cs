using Aplicacion;
using Infraestructura;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Identity.Web;
using Microsoft.Win32;
using OpenTelemetry.Logs;
using OpenTelemetry.Metrics;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using Presentacion.ManejadorExcepciones;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
//builder.Services.AddOpenIddict()
//    .AddValidation(options =>
//    {
//        options.SetIssuer("https://localhost:5068/");
//        options.AddAudiences("arquitecturabase.api");

//        options.UseSystemNetHttp();
//        options.UseAspNetCore();
//    });


builder.Services.AddInfraestructuraServicios(builder.Configuration);
builder.Services.AddAplicacionServicios();
builder.Services.AddProblemDetails();
builder.Services.AddExceptionHandler<GlobalExceptionHandler>();


builder.Services.AddControllers();
// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();
builder.Services.AddSwaggerGen();
const string serviceName = "MiServicioAspNet";

// 1. Configurar Trazas y Métricas
builder.Services.AddOpenTelemetry()
    .ConfigureResource(resource => resource.AddService(serviceName))
    .WithTracing(tracing => tracing
        .AddAspNetCoreInstrumentation() // Trazas de peticiones entrantes
        .AddHttpClientInstrumentation() // Trazas de peticiones salientes (HttpClient)
        .AddConsoleExporter()           // Ver en consola (desarrollo)
        .AddOtlpExporter())             // Enviar a Jaeger, Grafana Tempo, Aspire, etc.
    .WithMetrics(metrics => metrics
        .AddAspNetCoreInstrumentation() // Métricas de Kestrel y rutas
        .AddHttpClientInstrumentation()
        .AddConsoleExporter()
        .AddOtlpExporter());

// 2. Integrar Logs estructurados con ILogger
builder.Logging.AddOpenTelemetry(logging =>
{
    logging.IncludeFormattedMessage = true;
    logging.IncludeScopes = true;
    logging.AddConsoleExporter();
    logging.AddOtlpExporter();
});


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseExceptionHandler();
app.UseHttpsRedirection();

app.UseAuthentication();

app.UseAuthorization();

app.MapControllers();

app.MapGet("/", (ILogger<Program> logger) =>
{
    logger.LogInformation("Petición recibida con correlación automática de TraceId");
    return "OpenTelemetry activo";
});

app.Run();
